import React from 'react';
import './App.css';
import Home from './Pages/Home';
import Routes from './routes';
 
function App() {
  return (
    <Routes />
  )
}
 export default App;